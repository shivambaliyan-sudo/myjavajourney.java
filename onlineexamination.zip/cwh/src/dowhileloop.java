public class dowhileloop {
    public static void main(String[] args) {
        int a= 10;
        do {
            System.out.println(a);
            a--;
        }while (a>=0);
    }
}

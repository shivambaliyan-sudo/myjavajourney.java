public class practiceset6 {
    public static void main(String[] args) {
        // sum of a array
//        float a [] = {20.5f, 15.6f, 12.5f, 20.8f} ;
//        float sum = 0;
//        for (float element : a){
//            sum = sum+ element;
//        }
//        System.out.println(sum);

        
    }
    }


public class patternusingloop {
    public static void main(String[] args) {
       int  n=130;
        for (int i=n; i>0; i--) {
            for (int j=0; j<i; j++) {

                System.out.print("*");
            }

            System.out.println("\n");
        }



    }
}

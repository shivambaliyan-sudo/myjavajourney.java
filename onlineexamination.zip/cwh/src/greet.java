import java.util.Scanner;
public class greet {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("what is your name ");
        String a  = sc.nextLine();
        System.out.print("Hi "+a+" I am dfgds  ");


    }
}

import java.util.Scanner;

public class checkint{

    public static void main(String[]args){
Scanner sc = new Scanner(System.in);
        System.out.println("enter any no. to check it is integer or not");
        System.out.println(sc.hasNextInt());
    }
}

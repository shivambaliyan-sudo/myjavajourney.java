
public class string {
    public static void main(String[] args) {

        String a = "  Ha rry  ";

//        System.out.println("length of string");
//        int value = a.length();
//        System.out.println(value);

//        System.out.println("convert string to lower case");
//       String b = a.toLowerCase();
//        System.out.println(b);

//        System.out.println("replace space with underscore");


//         System.out.println(a.replace( ' ', '-'));

        System.out.println("adding double upper commas using backslash");
        System.out.println("  \"replace the name  shivam baliyan\"  ");





    }
}

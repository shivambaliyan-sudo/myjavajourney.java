public class whileloop {
    public static void main(String[] args) {
//        int i = 100;
//        while (i>=30) {
//            System.out.println("print "+i);
//            i--;
//        }

        //problem sum of first n even no.








    }
}
